
import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class BusquedaHilos {

    public static void main(String[] args) {
        
        //creación y ejecución de los hilos
        int [] array_datos = { 12,7,3,11,9,0,13,5,7,10,2,1,6,4,8, 12, 71, 73, 75, 77, 79, 72, 74, 76, 78, 61, 63, 65, 67, 69, 81};
        int dato;
        
        do{
            dato=Integer.parseInt(JOptionPane.showInputDialog("Digite el dato a buscar en el arreglo"));
        
            HiloBuscadorInicio binicio = new HiloBuscadorInicio(dato, array_datos, "hilo Inicio");
            HiloBuscadorFinal runn_bfinal = new HiloBuscadorFinal(dato, array_datos, "hilo final");
            Thread bfinal = new Thread(runn_bfinal);

            binicio.start();
            bfinal.start();
            while(binicio.isAlive()|| bfinal.isAlive() ){
                System.out.println ("Hilos Activos");
            };
        }while (dato !=-1);
    }
}
