/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package piHilos;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class Proceso extends Thread {
    String mensaje;
    
	public Proceso(String msg)
	{
		super(msg);
              
                
	}
	
	public void run()
	{
		for(int i =0; i<100;i++)
		{
			System.out.println(mensaje);
                        
                        
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Proceso.class.getName()).log(Level.SEVERE, null, ex);
                    }
		}
		System.out.println("Este proceso ha terminado: "+this.getName());
	}
	
	public void setMensaje(String msj)
	{
		this.mensaje = msj;
	}


    
    public static void main(String[] args) {
		// TODO Auto-generated method stub

		Proceso hilo1 = new Proceso("Hilo 1");
		Proceso hilo2 = new Proceso("Hilo 2");
                Proceso hilo3 = new Proceso("Hilo 3");
		Proceso hilo4 = new Proceso("Hilo 4");
                Proceso hilo5 = new Proceso("Hilo 5");
                
		hilo1.setMensaje("Hilo 1");
		hilo2.setMensaje("Hilo 2");
                hilo3.setMensaje("Hilo 3");
		hilo4.setMensaje("Hilo 4");
                hilo5.setMensaje("Hilo 5");
		
		hilo1.start();
		hilo2.start();
                hilo3.start();
		hilo4.start();
                hilo5.start();
		
	
	}//Main
}//class
