
public class HiloBuscadorFinal implements Runnable{

    int datoBuscado;
    int arreglo[];
    int numOper;
    boolean termino;
    String idHilo;
    int i;

    public HiloBuscadorFinal(int dato, int[] arr, String id) {
        datoBuscado=dato;
        arreglo=arr;
        numOper=0;
        idHilo=id;
        termino=false;
    }
    
    
    
    @Override
    public void run() {
        int tamaño=(int)Math.floor(arreglo.length/2);
        System.out.println("--------------- Se busca entre "+tamaño+" y "+arreglo.length+" hilo "+idHilo);
        for ( i = (arreglo.length-1); i > tamaño; i--) {
            System.out.println("hilo: "+idHilo+" operaciones: "+numOper);
            if(arreglo[i]==datoBuscado){
                System.out.println("Dato encontrado! por hilo: "+idHilo+" - "+datoBuscado+" en posición["+i+"]");
                termino=true;
            }
            if(termino){
                return;
            }else{
                numOper++;
            }
        }
        if(numOper==i){
            System.out.println("****** El hilo: "+idHilo+" No encontró el valor");
        }
        System.out.println("++++++++ Se terminó el hilo: "+idHilo);
    }
    
}
