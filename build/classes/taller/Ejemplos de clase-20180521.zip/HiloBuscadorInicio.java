
/**
 *
 * @author USUARIO
 */
public class HiloBuscadorInicio extends Thread{
    
    int datoBuscado;
    int arreglo[];
    int numOper;
    boolean termino;
    String idHilo;
    int i;

    public HiloBuscadorInicio(int dato, int[] arr, String id) {
        datoBuscado=dato;
        arreglo=arr;
        numOper=0;
        idHilo=id;
        termino=false;
        
    }
    
    public void run() {
        int tamaño=(int)Math.floor(arreglo.length/2);
        System.out.println("--------------- Se busca entre 0 y "+tamaño+" hilo "+idHilo);
        for ( i = 0; i < tamaño; i++) {
            System.out.println("hilo: "+idHilo+" operaciones: "+numOper);
            if(arreglo[i]==datoBuscado){
                System.out.println("Dato encontrado! por hilo: "+idHilo+" - "+datoBuscado+" en posición["+i+"]");
                termino=true;
            }
            if(termino){
                break;
            }else{
                numOper++;
           }
        }
        if(numOper==i){
            System.out.println("**** El hilo: "+idHilo+" No encontró el valor ****");
        }
        System.out.println("+++++++++ Se terminó el hilo: "+idHilo);
    }
    
    
}
